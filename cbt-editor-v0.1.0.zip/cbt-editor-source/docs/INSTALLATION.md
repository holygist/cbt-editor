# Installation

## Option A: Plain `<script>` tag — No build tools

This is the primary path. Copy three things into your project:

```
your-project/
├── cbt-editor.min.js    ← the editor bundle
├── cbt-editor.min.css   ← styles
└── fonts/               ← MathLive math fonts (required for rendering)
```

Then in any HTML or PHP page:

```html
<link rel="stylesheet" href="cbt-editor.min.css">
<script src="cbt-editor.min.js"></script>
<div id="editor"></div>
<script>
  // Tell MathLive where to find its fonts (relative to this HTML page)
  CBTEditor.setMathLiveFontsDir('./fonts');

  const editor = new CBTEditor({
    target: document.getElementById('editor')
  });
</script>
```

**That's it.** No `npm install`, no webpack, no build step. Works in:

- Plain `.html` files
- PHP templates (`<?php ... ?>` — just echo the script tags)
- WordPress page templates
- Any CMS that lets you add `<script>` tags

### Using in PHP / WordPress

```php
<!-- In header.php or a page template -->
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/cbt-editor/cbt-editor.min.css">
<script src="<?php echo get_template_directory_uri(); ?>/cbt-editor/cbt-editor.min.js"></script>

<!-- In your page template -->
<div id="my-editor"></div>
<script>
CBTEditor.setMathLiveFontsDir('<?php echo get_template_directory_uri(); ?>/cbt-editor/fonts');
new CBTEditor({ target: document.getElementById('my-editor') });
</script>
```

---

## Option B: npm + bundler

```bash
npm install cbt-editor
```

```js
import CBTEditor from 'cbt-editor';
// Also import the CSS (depends on your bundler's CSS support):
import 'cbt-editor/dist/cbt-editor.min.css';

CBTEditor.setMathLiveFontsDir('/node_modules/cbt-editor/dist/fonts');

const editor = new CBTEditor({
  target: document.getElementById('editor')
});
```

### Peer dependencies (npm users only)

The npm package lists TipTap packages as peer dependencies so your bundler can deduplicate them. If you use the `<script>` tag path, everything is bundled — no peer dependencies to worry about.

---

## Verifying it works

Open your page in a browser. You should see:

1. A toolbar with formatting buttons (¶, H1, B, I, etc.)
2. Buttons for Math (📐) and Chemistry (⚗️)
3. A typing area where you can enter and format text
4. Click **📂 Load Sample** to see math and chemistry blocks in action

Open the browser console (F12) and click **💾 Save** — you'll see the full document JSON printed there.
