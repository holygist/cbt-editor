# Contributing

Thanks for considering contributing to CBTEditor!

## Getting started

```bash
git clone <repo-url>
cd cbt-editor
npm install
npm run build
open test/index.html  # verify it works
```

## Development workflow

1. Make changes in `src/`
2. Rebuild: `npm run build`
3. Test by opening `test/index.html` in a browser
4. Check browser console for errors

## Coding style

- **Vanilla JavaScript** (ES modules). No TypeScript, no React, no JSX.
- Use `class` syntax for components, factory functions for TipTap nodes.
- CSS uses the `cbt-` prefix for all class names to avoid conflicts.
- DOM manipulation uses native APIs (`document.createElement`, `addEventListener`, etc.) — no jQuery or other libraries.
- NodeViews follow the pattern established by MathBlock and ChemBlock (see [EXTENDING.md](EXTENDING.md)).

## Project structure

```
src/
├── CBTEditor.js          ← Main class
├── CBTEditor.css         ← All styles
└── nodes/
    ├── MathBlock.js      ← Math node
    └── ChemBlock.js      ← Chemistry node
```

## Adding a new node type

Follow the step-by-step guide in [EXTENDING.md](EXTENDING.md). The key pattern:

1. Create `src/nodes/YourBlock.js` following the NodeView pattern
2. Import and register it in `CBTEditor.js`
3. Add a toolbar button
4. Add CSS
5. Test round-tripping (save → reload → still editable)

## Before submitting

- [ ] `npm run build` succeeds without errors
- [ ] `test/index.html` works in a browser
- [ ] Math blocks insert, edit, and save correctly
- [ ] Chemistry blocks insert, edit, and save correctly
- [ ] Export methods (`exportToHTML`, `exportMathAsLatex`, `exportChemAsJSON`) return expected results
- [ ] Round-trip test passes (save → clear → reload → content intact)
- [ ] No new console errors

## License

By contributing, you agree that your contributions will be licensed under the MIT License.
