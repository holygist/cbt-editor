# Usage & API Reference

## Creating an editor

```js
// Works like a <textarea> replacement — embed in any <form>
new CBTEditor({
  target: document.getElementById('editor'),  // REQUIRED: container element
  name: 'content',                             // optional: form field name
  value: savedDocumentJSON,                    // optional: pre-load content
  readOnly: false,                             // optional: default false
  onChange: (json) => { /* handle change */ }  // optional: fires on every edit
});
```

---

## Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `target` | `HTMLElement` | *(required)* | The DOM element to mount the editor into |
| `name` | `string` | `null` | Form field name. Creates `<input type="hidden" name="X">` that auto-syncs. Submit your form normally — `$_POST['X']` contains the document JSON. |
| `value` | `Object` | `null` | A TipTap-compatible JSON document to pre-load (for editing existing content) |
| `readOnly` | `boolean` | `false` | Whether the editor is read-only |
| `onChange` | `Function` | `null` | Called with the document JSON on every content change |

---

## Methods

### `editor.getJSON()`

Returns the full document as a TipTap-compatible JSON object.

```js
const doc = editor.getJSON();
console.log(doc); // { type: 'doc', content: [...] }
```

### `editor.getHTML()`

Returns the document as an HTML string.

```js
const html = editor.getHTML();
```

### `editor.loadJSON(json)`

Loads a document from a TipTap-compatible JSON object (replaces current content).

```js
editor.loadJSON(savedDocument);
```

### `editor.setReadOnly(bool)`

Toggles read-only mode.

```js
editor.setReadOnly(true);  // disable editing
editor.setReadOnly(false); // enable editing
```

### `editor.destroy()`

Destroys the editor instance and cleans up the DOM.

```js
editor.destroy();
```

### `editor.on(event, callback)`

Register an event listener. Supports `'change'` — fires with JSON on every edit.

```js
editor.on('change', (json) => {
  console.log('Content updated:', json);
});
```

---

## Export / Interop Methods

### `editor.exportToHTML()`

Returns the document as an HTML string, suitable for PDF generation or web display.

```js
const html = editor.exportToHTML();
```

### `editor.exportMathAsLatex()`

Extracts LaTeX strings from all MathBlocks in the document. Returns an array of `{ latex: string }` objects.

```js
const equations = editor.exportMathAsLatex();
equations.forEach(eq => console.log(eq.latex));
// e.g. "\frac{-b \pm \sqrt{b^2 - 4ac}}{2a}"
```

### `editor.exportChemAsJSON()`

Extracts chemistry formula trees from all ChemBlocks. Returns an array of parsed formula objects.

```js
const formulas = editor.exportChemAsJSON();
formulas.forEach(f => console.log(f));
// { terms: [{ coefficient: 2, groups: [{ symbol: 'H', subscript: '2' }] }, ...] }
```

### `editor.importFromJSON(json)`

Loads a document from saved JSON. Returns `true` on success, `false` if the JSON is invalid.

```js
const success = editor.importFromJSON(savedJSON);
if (!success) console.error('Invalid document');
```

---

## Static Methods

### `CBTEditor.setMathLiveFontsDir(dir)`

Sets the directory where MathLive looks for its KaTeX font files. Call this **once** before creating any editor instance.

```js
CBTEditor.setMathLiveFontsDir('./fonts');
// or if fonts are in a subfolder:
CBTEditor.setMathLiveFontsDir('/assets/mathlive-fonts');
```

Default: `'./fonts'` (relative to the HTML page).

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+Shift+M` / `Cmd+Shift+M` | Insert Math block |
| `Ctrl+Shift+C` / `Cmd+Shift+C` | Insert Chemistry block |
| `Ctrl+Z` / `Cmd+Z` | Undo |
| `Ctrl+Shift+Z` / `Cmd+Shift+Z` | Redo |
| `Ctrl+B` / `Cmd+B` | Bold |
| `Ctrl+I` / `Cmd+I` | Italic |
| `Escape` (inside math block) | Exit math editing |

---

## Toolbar Buttons

| Button | Description |
|--------|-------------|
| ¶ | Paragraph |
| H1 / H2 / H3 | Heading levels 1–3 |
| **B** | Bold |
| *I* | Italic |
| • List | Bullet list |
| 1. List | Numbered list |
| ⊞ Table | Insert 3×3 table with header row |
| 📐 Math | Insert visual math block (MathLive) |
| ⚗️ Chem | Insert chemistry formula builder |
| ↩ / ↪ | Undo / Redo |

---

## Customizing the Toolbar

The toolbar is built with plain HTML inside `CBTEditor._toolbarHTML()`. To add or remove buttons, extend the class:

```js
class MyEditor extends CBTEditor {
  _toolbarHTML() {
    const base = super._toolbarHTML();
    // Add a custom button
    return base.replace('</div>', '<button data-action="myAction">Custom</button></div>');
  }
}
```

See [EXTENDING.md](EXTENDING.md) for a complete guide.

---

## Styling / Theming

All editor elements use the `cbt-` CSS class prefix. Override these to theme the editor:

```css
/* Change toolbar background */
.cbt-toolbar { background: #your-color; }

/* Change math block border color */
.cbt-math-block { border-color: #your-color; }

/* Change chemistry block border color */
.cbt-chem-block { border-color: #your-color; }

/* Change save button color */
.cbt-btn-save { background: #your-color; }
```

---

## Content Format (JSON)

Documents use TipTap's JSON schema. Math and chemistry blocks are custom nodes:

```json
{
  "type": "doc",
  "content": [
    { "type": "paragraph", "content": [{ "type": "text", "text": "Hello" }] },
    {
      "type": "mathBlock",
      "attrs": { "latex": "\\frac{1}{2}" }
    },
    {
      "type": "chemBlock",
      "attrs": {
        "formula": "{\"terms\":[{\"coefficient\":1,\"groups\":[{\"symbol\":\"H\",\"subscript\":\"2\"}]}]}"
      }
    }
  ]
}
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for details on the internal data models.
