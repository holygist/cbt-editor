# Extending CBTEditor

This guide shows you how to add a new custom block type (e.g. `GraphBlock`, `CodeBlock`, `DiagramBlock`) following the same pattern as MathBlock and ChemBlock.

---

## Step 1: Create the Node file

Create `src/nodes/GraphBlock.js`:

```js
import { Node } from '@tiptap/core';

const GraphBlock = Node.create({
  name: 'graphBlock',       // Must be unique — used in JSON schema

  group: 'block',           // Block-level element (not inline)

  atom: true,               // Treat as an atomic unit (no nested text editing)

  inline: false,

  draggable: true,          // Allow drag-and-drop reordering

  // ── Attributes (stored in JSON) ─────────────────────────────
  addAttributes() {
    return {
      data: {
        default: '{}',  // Default value
        parseHTML: (el) => el.getAttribute('data-graph') || '{}',
        renderHTML: (attrs) => ({ 'data-graph': attrs.data }),
      },
    };
  },

  // ── HTML parsing (for paste / export) ───────────────────────
  parseHTML() {
    return [{ tag: 'div[data-graph-block]' }];
  },

  // ── Static HTML render (fallback for non-JS contexts) ──────
  renderHTML({ node }) {
    return [
      'div',
      {
        'data-graph-block': '',
        'data-graph': node.attrs.data,
        class: 'cbt-graph-block',
      },
      ['span', {}, '📊 Graph'],
    ];
  },

  // ── Interactive NodeView ────────────────────────────────────
  addNodeView() {
    return ({ node, getPos, editor }) => {
      const wrapper = document.createElement('div');
      wrapper.className = 'cbt-graph-block';
      wrapper.setAttribute('data-graph-block', '');

      // Build your custom UI here
      const canvas = document.createElement('canvas');
      canvas.width = 400;
      canvas.height = 200;
      wrapper.appendChild(canvas);

      // ... your rendering/editing logic ...

      return {
        dom: wrapper,

        update(updatedNode) {
          // Sync when attributes change externally
          if (updatedNode.attrs.data !== node.attrs.data) {
            // Re-render with new data
          }
          return true;
        },

        ignoreMutation(mutation) {
          // Prevent TipTap from overwriting your DOM
          return wrapper.contains(mutation.target);
        },

        destroy() {
          // Clean up event listeners, timers, etc.
        },

        stopEvent(e) {
          // Prevent TipTap from capturing events inside your block
          return wrapper.contains(e.target);
        },
      };
    };
  },

  // ── Editor command (accessible from toolbar/API) ────────────
  addCommands() {
    return {
      insertGraphBlock:
        () =>
        ({ chain }) => {
          return chain()
            .insertContent({ type: 'graphBlock', attrs: { data: '{}' } })
            .run();
        },
    };
  },
});

export default GraphBlock;
```

---

## Step 2: Register the node in CBTEditor

In `src/CBTEditor.js`:

```js
import GraphBlock from './nodes/GraphBlock.js';

// In _createTipTapEditor(), add to the extensions array:
extensions: [
  StarterKit.configure({ heading: { levels: [1, 2, 3] } }),
  Table.configure({ resizable: true }),
  TableRow, TableCell, TableHeader,
  MathBlock,
  ChemBlock,
  GraphBlock,          // ← Add your node here
],
```

---

## Step 3: Add a toolbar button

In `src/CBTEditor.js`, add to `_toolbarHTML()`:

```html
<button class="cbt-btn" data-action="insertGraphBlock" title="Insert Graph">📊 Graph</button>
```

Add to the `switch` in `_bindToolbarEvents()`:

```js
case 'insertGraphBlock':
  this._editor.chain().focus().insertGraphBlock().run();
  break;
```

---

## Step 4: Add CSS

In `src/CBTEditor.css`:

```css
.cbt-graph-block {
  margin: 12px 0;
  padding: 10px;
  border: 2px dashed #c4b5fd;
  border-radius: 8px;
  background: #f5f3ff;
  cursor: pointer;
}
.cbt-graph-block:hover {
  border-color: #8b5cf6;
}
```

---

## Step 5: Update export methods (if needed)

If your block stores structured data that should be exportable, add a method to `CBTEditor`:

```js
exportGraphData() {
  const json = this.getJSON();
  const results = [];
  const walk = (nodes) => {
    for (const node of nodes) {
      if (node.type === 'graphBlock') {
        results.push(JSON.parse(node.attrs?.data || '{}'));
      }
      if (node.content) walk(node.content);
    }
  };
  walk(json.content);
  return results;
}
```

---

## Step 6: Rebuild

```bash
npm run build
```

Your new block is now part of the UMD bundle and ready to use.

---

## Design principles (follow these for any new block)

1. **Store data in attributes, not as child content.** Custom blocks should be `atom: true` and store their state in node attributes. This keeps the document model flat and serializable.

2. **Use `ignoreMutation`.** Always return `true` for mutations inside your wrapper DOM — otherwise TipTap will try to "fix" your custom UI.

3. **Use `stopEvent`.** Prevent TipTap from intercepting clicks/keypresses inside your block.

4. **Provide a static `renderHTML`.** This is the fallback when JavaScript isn't available (e.g., server-side rendering, plain HTML export).

5. **Keep the editor UI self-contained.** Don't require external UI libraries. Build with plain DOM APIs (or canvas/SVG) — this keeps the bundle small and avoids framework dependencies.

6. **Test round-tripping.** Save a document containing your block, reload it, and confirm the block is still editable. The `importFromJSON` → `getJSON` cycle must preserve all attributes.
