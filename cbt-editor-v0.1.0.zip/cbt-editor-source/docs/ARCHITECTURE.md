# Architecture

CBTEditor is built in three independent layers, following a shell + plugins pattern.

```
CBTEditor (public API)
│
├── Shell: TipTap (ProseMirror)          ← document model, toolbar, formatting
│     MIT license
│
├── Custom Node: MathBlock               ← visual math editing
│     wraps MathLive (<math-field>)       ← MIT license
│     stores content as LaTeX string
│
└── Custom Node: ChemBlock               ← visual chemistry formula editing
      custom tree-based model
      stores formula tree as JSON string
```

---

## Why this architecture?

### 1. Shell (TipTap)

TipTap (built on ProseMirror) handles the hard parts of a rich text editor:
- Document model and state management
- Selection, cursor, and keyboard handling
- Undo/redo history
- Serialization to/from JSON and HTML
- Table editing
- Extensibility via a node/extension system

We use **`@tiptap/core`** directly, not `@tiptap/react`. This makes the package framework-agnostic. The toolbar is built with plain DOM elements and event delegation, not React components.

### 2. MathBlock

MathBlock is a custom TipTap **Node** — it plugs into TipTap's document schema as a block-level element. It uses TipTap's **NodeView** API to render a MathLive `<math-field>` web component at the node's position in the document.

- **Storage**: The LaTeX string is stored as a node attribute (`attrs.latex`)
- **Editing**: Clicking the display toggles the math-field into edit mode
- **Serialization**: Node attributes are included in TipTap's JSON output
- **Keyboard nav**: Escape, ArrowUp/Down, Ctrl+Enter navigate in/out of the math field

MathLive itself is MIT-licensed and provides:
- Visual fraction/superscript/subscript editing
- A tap-to-build virtual keyboard
- LaTeX and MathJSON import/export
- Screen reader support

### 3. ChemBlock

ChemBlock is also a custom TipTap **Node** with its own small visual editor built in plain HTML/CSS.

**Data model** (stored as JSON string in `attrs.formula`):

```json
{
  "terms": [
    {
      "coefficient": 2,
      "groups": [
        { "symbol": "H", "subscript": "2", "superscript": "" }
      ]
    },
    { "operator": "+" },
    {
      "coefficient": 1,
      "groups": [
        { "symbol": "O", "subscript": "2", "superscript": "" }
      ]
    },
    { "operator": "→" },
    {
      "coefficient": 2,
      "groups": [
        { "symbol": "H", "subscript": "2", "superscript": "" },
        { "symbol": "O", "subscript": "1", "superscript": "" }
      ]
    }
  ]
}
```

Terms alternate between molecule terms (coefficient + atom groups) and operator terms (`+`, `→`, `⇌`, `←`, etc.).

---

## File structure

```
src/
├── CBTEditor.js          ← Main class: public API, toolbar, event binding
├── CBTEditor.css         ← All editor styles
└── nodes/
    ├── MathBlock.js      ← TipTap Node for math (MathLive integration)
    └── ChemBlock.js      ← TipTap Node for chemistry formulas
```

---

## Build outputs

| File | Format | Purpose |
|------|--------|---------|
| `dist/cbt-editor.min.js` | UMD (minified) | Drop-in `<script>` tag usage |
| `dist/cbt-editor.min.css` | CSS (minified) | All styles |
| `dist/cbt-editor.esm.js` | ES Module | npm/bundler users |
| `dist/cbt-editor.cjs.js` | CommonJS | Node/require users |
| `dist/fonts/` | WOFF2 fonts | MathLive KaTeX fonts |

---

## Key design decisions

1. **No React dependency.** TipTap core is vanilla JS. The React wrapper (`@tiptap/react`) is purposefully avoided so the package works in any environment.

2. **UMD as primary format.** Most CBTEditor users drop a `<script>` tag into a PHP page or CMS template. The UMD bundle includes TipTap + MathLive + our code in one file.

3. **NodeView for custom blocks.** TipTap's NodeView API gives us full control over DOM rendering while staying inside the ProseMirror document model — custom nodes participate in undo/redo, serialization, and cursor navigation.

4. **LaTeX as math storage format.** MathLive can also export MathJSON (more machine-readable), but LaTeX is universally understood by math tools (KaTeX, MathJax, Pandoc, etc.) and is human-readable.

5. **JSON-string-in-attribute for chemistry.** The chemistry formula tree is serialized as a JSON string stored in a node attribute. This keeps the TipTap schema simple (no nested custom types) while allowing arbitrarily complex formulas.
