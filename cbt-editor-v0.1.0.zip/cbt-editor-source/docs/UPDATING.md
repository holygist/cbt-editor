# Updating CBTEditor

## Versioning

CBTEditor follows **Semantic Versioning** (MAJOR.MINOR.PATCH):

- **MAJOR**: Breaking changes to the public API or document format (old saved JSON may not load correctly)
- **MINOR**: New features (new node types, export methods, toolbar options) — backward compatible
- **PATCH**: Bug fixes — fully backward compatible

---

## Before releasing a new version

### 1. Test backward compatibility of saved documents

**This is the most important step.** Users have saved documents built with previous versions. After any change to how math or chemistry content is stored (attributes, schema, data model), you MUST verify that old documents still open correctly.

```js
// Test: load an old document, save it, reload it
const oldDoc = { /* JSON from a previous version */ };
editor.importFromJSON(oldDoc);

// Verify all math blocks are still editable
const mathBlocks = editor.exportMathAsLatex();
console.assert(mathBlocks.length > 0, 'Math blocks should survive reload');

// Verify all chem blocks are still editable
const chemBlocks = editor.exportChemAsJSON();
console.assert(chemBlocks.length > 0, 'Chem blocks should survive reload');

// Full round-trip
const saved = editor.getJSON();
const reloaded = editor.importFromJSON(saved);
console.assert(reloaded, 'Round-trip should succeed');
```

### 2. Check the public API

- Are all documented methods still working? (`getJSON`, `loadJSON`, `exportToHTML`, `exportMathAsLatex`, `exportChemAsJSON`, `importFromJSON`, `destroy`, `setReadOnly`)
- Is the constructor signature unchanged? (`{ target, initialContent, onSave, readOnly }`)
- Is `CBTEditor.setMathLiveFontsDir()` still callable?

### 3. Test both distribution paths

```bash
# UMD (script tag)
open test/index.html   # verify everything works

# npm (ESM)
# Create a small test project that does: import CBTEditor from 'cbt-editor'
```

### 4. Build and check sizes

```bash
npm run build
ls -lh dist/cbt-editor.min.js
ls -lh dist/cbt-editor.min.css
```

If the bundle size increased significantly, investigate why before releasing.

---

## Writing a CHANGELOG entry

Add to `CHANGELOG.md`:

```markdown
## [1.2.0] - 2026-07-09

### Added
- New `exportMathAsLatex()` method for extracting LaTeX from math blocks
- New `exportChemAsJSON()` method for extracting formula trees

### Fixed
- MathLive font path resolution on subdirectory deployments

### Changed
- ChemBlock editor now uses dropdown selectors for operators instead of text inputs
```

---

## Releasing

1. Update version in `package.json`
2. Update `CHANGELOG.md`
3. Run `npm run build`
4. Run the release script: `bash build-release.sh`
5. Upload the `public-release/` folder to your hosting
6. Tag the release in git: `git tag v1.2.0 && git push --tags`

---

## Backward compatibility guide

### If you need to change the MathBlock storage format

**Old format** (LaTeX string in attribute):
```json
{ "type": "mathBlock", "attrs": { "latex": "\\frac{1}{2}" } }
```

**New format** (add MathJSON alongside LaTeX):
```json
{ "type": "mathBlock", "attrs": { "latex": "\\frac{1}{2}", "mathjson": "..." } }
```

You MUST handle both formats in `addAttributes()`:

```js
addAttributes() {
  return {
    latex: {
      default: '',
      parseHTML: (el) => el.getAttribute('data-latex') || '',
    },
    mathjson: {
      default: null,  // null means "not present in old documents"
      parseHTML: (el) => el.getAttribute('data-mathjson') || null,
    },
  };
}
```

And in the NodeView, handle the case where `mathjson` is null:

```js
if (!node.attrs.mathjson) {
  // Convert from LaTeX to MathJSON on first load
  node.attrs.mathjson = convertLatexToMathJSON(node.attrs.latex);
}
```

### If you need to change the ChemBlock data model

Add a **schema version** field:

```json
{
  "schemaVersion": 2,
  "terms": [...]
}
```

In `parseFormula()`:

```js
function parseFormula(raw) {
  const parsed = JSON.parse(raw);
  if (parsed.schemaVersion === 1) {
    return migrateV1ToV2(parsed);
  }
  return parsed;
}
```

This way, documents from any version can be loaded, and you can write migration functions for each version change.
