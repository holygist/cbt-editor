# Changelog

All notable changes to CBTEditor will be documented in this file.

## [0.1.0] - 2026-07-09

### Added
- Initial release
- Rich text editing: paragraphs, headings (H1–H3), bold, italic, bullet/numbered lists
- Table insertion with header rows (3×3)
- **MathBlock**: visual math editing powered by MathLive (tap-to-build fractions, superscripts, symbols)
  - LaTeX storage in document JSON
  - Click-to-edit: click a rendered equation to open the math editor
  - Keyboard navigation: Escape, ArrowUp/Down, Ctrl+Enter to exit
  - Insert via toolbar (📐 Math) or Ctrl+Shift+M
- **ChemBlock**: visual chemistry formula editor
  - Click-to-build formulas with coefficients, element symbols, subscripts, superscripts (charges)
  - Reaction arrows (→, ⇌, ←, ⇀, ↽, ⇄) with dropdown selectors
  - JSON tree storage in document attributes
  - Insert via toolbar (⚗️ Chem) or Ctrl+Shift+C
- Save/Load: document JSON serialization and deserialization
- Export methods: `exportToHTML()`, `exportMathAsLatex()`, `exportChemAsJSON()`, `importFromJSON()`
- Undo/Redo with full history
- UMD bundle: single JS file + CSS file, no framework required
- ESM and CJS builds for npm/bundler users
- `CBTEditor.setMathLiveFontsDir()` static method for font path configuration
- Full documentation: README, INSTALLATION, USAGE, ARCHITECTURE, EXTENDING, UPDATING, CONTRIBUTING
- MIT License
