# CBTEditor

**Free, open-source WYSIWYG editor with visual math & chemistry editing.**

Built on TipTap (ProseMirror) + MathLive. No framework required — drop a `<script>` tag into any HTML page, PHP template, or CMS and you're done.

![CBTEditor screenshot](assets/screenshot.svg)

---

## Quick Start

### Option A: Plain `<script>` tag (no build tools)

```html
<form method="POST" action="/save.php">
  <input name="title" placeholder="Title">
  <div id="editor"></div>
  <button type="submit">Submit</button>
</form>

<link rel="stylesheet" href="cbt-editor.min.css">
<script src="cbt-editor.min.js"></script>
<script>
  CBTEditor.setMathLiveFontsDir('./fonts');
  new CBTEditor({
    target: document.getElementById('editor'),
    name: 'content'   // ← auto-syncs JSON to hidden <input name="content">
  });
</script>
```

Works in plain HTML, PHP, WordPress, any CMS. Zero build step.

### Option B: npm (if you use a bundler)

```bash
npm install cbt-editor
```

```js
import CBTEditor from 'cbt-editor';
new CBTEditor({ target: document.getElementById('editor'), name: 'content' });
```

---

## Features

- **Rich text**: headings (H1–H3), bold, italic, bullet/numbered lists, tables
- **Visual math** (📐): tap-to-build equations using MathLive — fractions, superscripts, symbols, no LaTeX typing required
- **Visual chemistry** (⚗️): click-to-build formulas — subscripts, charges, reaction arrows
- **Save/Load**: documents stored as JSON, fully serializable
- **Export**: HTML, LaTeX (math), structured JSON (chemistry)
- **Undo/Redo**: full history support
- **Framework-agnostic**: one JS file, one CSS file, works anywhere

---

## License

MIT — free for personal and commercial use.

## Documentation

- [Installation](docs/INSTALLATION.md)
- [Usage & API](docs/USAGE.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Extending with custom nodes](docs/EXTENDING.md)
- [Updating & backward compatibility](docs/UPDATING.md)
- [Contributing](docs/CONTRIBUTING.md)
